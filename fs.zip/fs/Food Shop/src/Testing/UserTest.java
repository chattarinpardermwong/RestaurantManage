package Testing;

import Model.User;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class UserTest {
        User user;
        @BeforeEach
         void init(){
            user = new User();
        }
        @Test
        public void testID(){
            user.setId("user123");
            assertEquals("user123",user.getId());
        }
        @Test
        public void testPassword(){
            user.setPassword("password123");
            assertEquals("password123",user.getPassword());
        }



}