package Testing;

import Model.MenuToIncome;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class MenuToIncomeTest {
    MenuToIncome schedule4;
    @BeforeEach
    public void init() {
        schedule4 = new MenuToIncome("schedule4", "500");
    }
    @Test
    public void testName(){
        schedule4.setName("name");
        assertEquals("name",schedule4.getName());
    }
    @Test
    public void testPrice(){
        schedule4.setPrice("100");
        assertEquals("100",schedule4.getPrice());
    }
}